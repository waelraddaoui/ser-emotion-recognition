import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.serstudio.app',
  appName: 'SER Studio',
  webDir: 'dist/frontend/browser',
  server: {
    // For local dev testing on a real device, uncomment and set your PC's IP:
    // url: 'http://192.168.1.X:4200',
    // cleartext: true,
    androidScheme: 'https'
  },
  android: {
    allowMixedContent: true
  }
};

export default config;
