export const environment = {
  production: true,
  webApiUrl: 'http://172.20.10.4:8001',
  nativeApiUrl: 'http://172.20.10.4:8001',
};
